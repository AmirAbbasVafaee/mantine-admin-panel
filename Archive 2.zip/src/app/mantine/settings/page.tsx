import { SettingsPage } from '@/components/dashboard/SettingsPage'

export default function SettingsRoute() {
  return <SettingsPage />
}
