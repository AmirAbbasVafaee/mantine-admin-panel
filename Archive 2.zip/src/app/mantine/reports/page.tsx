import { ReportsPage } from '@/components/dashboard/ReportsPage'

export default function ReportsRoute() {
  return <ReportsPage />
}
