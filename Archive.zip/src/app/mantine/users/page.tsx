import { UsersPage } from '@/components/dashboard/UsersPage'

export default function UsersRoute() {
  return <UsersPage />
}
