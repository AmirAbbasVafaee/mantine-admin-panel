import { DashboardPage } from '@/components/dashboard/DashboardPage'

export default function DashboardRoute() {
  return <DashboardPage />
}
