import { OrdersPage } from '@/components/dashboard/OrdersPage'

export default function OrdersRoute() {
  return <OrdersPage />
}
