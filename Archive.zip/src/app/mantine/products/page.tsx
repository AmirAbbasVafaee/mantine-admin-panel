import { ProductsPage } from '@/components/dashboard/ProductsPage'

export default function ProductsRoute() {
  return <ProductsPage />
}
